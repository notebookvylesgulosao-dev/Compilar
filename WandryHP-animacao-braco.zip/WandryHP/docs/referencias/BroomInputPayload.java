package com.wandryhp;

import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9135;
import net.minecraft.class_9139;

/** Cliente -> servidor: teclas pressionadas enquanto monta a vassoura (bits de BroomEntity). */
public record BroomInputPayload(int flags) implements class_8710 {
    public static final class_8710.class_9154<BroomInputPayload> ID = new class_8710.class_9154<>(WandryHP.id("broom_input"));
    public static final class_9139<class_9129, BroomInputPayload> CODEC =
        class_9139.method_56434(class_9135.field_48550, BroomInputPayload::flags, BroomInputPayload::new);
    @Override public class_8710.class_9154<? extends class_8710> method_56479() { return ID; }
}
