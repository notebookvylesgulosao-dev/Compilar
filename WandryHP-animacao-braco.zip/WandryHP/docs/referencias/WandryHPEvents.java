package com.wandryhp;

import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.class_1799;
import net.minecraft.class_2561;
import net.minecraft.class_3222;

/** Pacotes cliente -> servidor (roda de feitiços, ataque base, controles da vassoura). */
public final class WandryHPEvents {
    private WandryHPEvents() {}

    public static void initialize() {
        PayloadTypeRegistry.playC2S().register(SelectSpellPayload.ID, SelectSpellPayload.CODEC);
        PayloadTypeRegistry.playC2S().register(BaseAttackPayload.ID, BaseAttackPayload.CODEC);
        PayloadTypeRegistry.playC2S().register(BroomInputPayload.ID, BroomInputPayload.CODEC);

        ServerPlayNetworking.registerGlobalReceiver(SelectSpellPayload.ID, (payload, context) -> {
            class_3222 player = context.player();
            int index = payload.spell();
            if (index < 0 || index >= MagicWandItem.Spell.values().length) return;
            class_1799 stack = player.method_6047();
            if (!(stack.method_7909() instanceof MagicWandItem)) stack = player.method_6079();
            if (!(stack.method_7909() instanceof MagicWandItem)) return;
            MagicWandItem.Spell spell = MagicWandItem.Spell.values()[index];
            MagicWandItem.setSelectedSpell(stack, spell);
            player.method_7353(class_2561.method_43470("Feitiço: " + spell.displayName), true);
        });

        ServerPlayNetworking.registerGlobalReceiver(BaseAttackPayload.ID,
            (payload, context) -> MagicWandItem.baseAttack(context.player()));

        ServerPlayNetworking.registerGlobalReceiver(BroomInputPayload.ID, (payload, context) -> {
            if (context.player().method_5854() instanceof BroomEntity broom) broom.setInput(payload.flags());
        });
    }
}
