package com.wandryhp.client;

import com.wandryhp.SpellProjectileEntity;
import net.minecraft.class_10017;
import net.minecraft.class_3532;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_5617;
import net.minecraft.class_7833;
import net.minecraft.class_897;

public final class SpellProjectileRenderer extends class_897<SpellProjectileEntity, SpellProjectileRenderer.State> {
    public static final class State extends class_10017 {
        int model;
        float yaw, pitch;
    }

    public SpellProjectileRenderer(class_5617.class_5618 context) { super(context); }

    @Override public State method_55269() { return new State(); }

    @Override public void updateRenderState(SpellProjectileEntity entity, State state, float tickDelta) {
        super.method_62354(entity, state, tickDelta);
        state.model = class_3532.method_15340(entity.modelIndex(), 0, QuadModel.NAMES.length - 1);
        state.yaw = class_3532.method_16439(tickDelta, entity.field_5982, entity.method_36454());
        state.pitch = class_3532.method_16439(tickDelta, entity.field_6004, entity.method_36455());
    }

    @Override public void render(State state, class_4587 matrices, class_4597 vertexConsumers, int light) {
        matrices.method_22903();
        matrices.method_22904(0, 0.15, 0);
        matrices.method_22907(class_7833.field_40716.rotationDegrees(state.yaw));
        matrices.method_22907(class_7833.field_40714.rotationDegrees(-state.pitch));
        float scale = state.model < 7 ? 1.6f : 2.2f; // props são menores que as esferas dos feitiços
        matrices.method_22905(scale, scale, scale);
        QuadModel.get(QuadModel.NAMES[state.model]).render(matrices, vertexConsumers, light);
        matrices.method_22909();
        super.method_3936(state, matrices, vertexConsumers, light);
    }
}
