package com.wandryhp.client;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.wandryhp.WandryHP;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Map;
import net.minecraft.class_1921;
import net.minecraft.class_2960;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_4597;
import net.minecraft.class_4608;

/**
 * Modelo feito de quads pré-calculados a partir dos .bbmodel originais (tools/convert_models.py),
 * o que preserva rotações em vários eixos e UV por face que o formato JSON de item não suporta.
 * Dados em assets/wandry_hp/quads/<nome>.json, textura em textures/entity/<nome>.png.
 */
public final class QuadModel {
    /** 0-6 = feitiços (ordem de MagicWandItem.Spell), 7-11 = props de ataque base. */
    public static final String[] NAMES = {
        "avada_kedavra", "corinficus", "crucio", "expelliarmus", "imperius", "petrificus_totalis", "sectumsempra",
        "prop_amethyst", "prop_bone", "prop_celestial", "prop_dragon", "prop_widow"
    };
    private static final int STRIDE = 24; // 4 vértices x (x,y,z,u,v) + normal(3) + emissivo(1)
    private static final Map<String, QuadModel> CACHE = new HashMap<>();

    private final float[] data;
    private final class_1921 layer;

    private QuadModel(float[] data, class_2960 texture) {
        this.data = data;
        this.layer = class_1921.method_23578(texture);
    }

    public static QuadModel get(String name) {
        return CACHE.computeIfAbsent(name, QuadModel::load);
    }

    private static QuadModel load(String name) {
        try (InputStream in = QuadModel.class.getResourceAsStream("/assets/wandry_hp/quads/" + name + ".json")) {
            if (in == null) throw new IllegalStateException("Quads não encontrados: " + name);
            JsonObject root = JsonParser.parseReader(new InputStreamReader(in, StandardCharsets.UTF_8)).getAsJsonObject();
            JsonArray array = root.getAsJsonArray("quads");
            float[] data = new float[array.size()];
            for (int i = 0; i < data.length; i++) data[i] = array.get(i).getAsFloat();
            return new QuadModel(data, WandryHP.id("textures/entity/" + name + ".png"));
        } catch (java.io.IOException e) {
            throw new IllegalStateException(e);
        }
    }

    public void render(class_4587 matrices, class_4597 vertexConsumers, int light) {
        class_4588 consumer = vertexConsumers.getBuffer(layer);
        class_4587.class_4665 entry = matrices.method_23760();
        for (int o = 0; o + STRIDE <= data.length; o += STRIDE) {
            float nx = data[o + 20], ny = data[o + 21], nz = data[o + 22];
            int quadLight = data[o + 23] > 0.5f ? 0xF000F0 : light;
            for (int v = 0; v < 4; v++) {
                int i = o + v * 5;
                consumer.method_56824(entry, data[i], data[i + 1], data[i + 2])
                    .method_1336(255, 255, 255, 255)
                    .method_22913(data[i + 3], data[i + 4])
                    .method_22922(class_4608.field_21444)
                    .method_60803(quadLight)
                    .method_60831(entry, nx, ny, nz);
            }
        }
    }
}
