package com.wandryhp;

import net.minecraft.class_124;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2561;

/** Test-phase scroll: unlocks one of the seven currently specified spells as a wand item. */
public final class ScrollItem extends class_1792 {
    private static final class_1792[] REWARDS = { WandryHP.AMETHYST_WAND, WandryHP.BONE_WAND, WandryHP.CELESTIAL_WAND,
            WandryHP.DRAGON_WAND, WandryHP.EMERALD_WAND, WandryHP.MAGMA_WAND, WandryHP.WIDOW_WAND };
    public ScrollItem(class_1793 settings) { super(settings); }
    @Override public class_1269 method_7836(class_1937 world, class_1657 user, class_1268 hand) {
        class_1799 stack = user.method_5998(hand);
        if (!world.field_9236) {
            if (world.field_9229.method_43057() < .20f) {
                user.method_7353(class_2561.method_43470("O pergaminho não continha nenhum feitiço.").method_27692(class_124.field_1080), true);
            } else {
                java.util.List<class_1792> available = new java.util.ArrayList<>();
                for (class_1792 reward : REWARDS) if (!user.method_31548().method_7379(new class_1799(reward))) available.add(reward);
                if (available.isEmpty()) {
                    user.method_7353(class_2561.method_43470("Você já desbloqueou todas as varinhas disponíveis nesta versão.").method_27692(class_124.field_1080), true);
                    return class_1269.field_5812;
                }
                class_1792 reward = available.get(world.field_9229.method_43048(available.size()));
                class_1799 wand = new class_1799(reward);
                if (!user.method_31548().method_7394(wand)) user.method_7328(wand, false);
                user.method_7353(class_2561.method_43470("Feitiço desbloqueado: ").method_10852(reward.method_63680()).method_27692(class_124.field_1076), true);
            }
            if (!user.method_31549().field_7477) stack.method_7934(1);
        }
        return class_1269.field_5812;
    }
}
