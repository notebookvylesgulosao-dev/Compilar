package com.wandryhp;

import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9135;
import net.minecraft.class_9139;

/** Cliente -> servidor: feitiço escolhido na roda para a varinha na mão. */
public record SelectSpellPayload(int spell) implements class_8710 {
    public static final class_8710.class_9154<SelectSpellPayload> ID = new class_8710.class_9154<>(WandryHP.id("select_spell"));
    public static final class_9139<class_9129, SelectSpellPayload> CODEC =
        class_9139.method_56434(class_9135.field_48550, SelectSpellPayload::spell, SelectSpellPayload::new);
    @Override public class_8710.class_9154<? extends class_8710> method_56479() { return ID; }
}
