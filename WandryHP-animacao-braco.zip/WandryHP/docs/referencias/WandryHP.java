package com.wandryhp;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.itemgroup.v1.FabricItemGroup;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1304;
import net.minecraft.class_1311;
import net.minecraft.class_1322;
import net.minecraft.class_1761;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_2378;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_5134;
import net.minecraft.class_5321;
import net.minecraft.class_7923;
import net.minecraft.class_7924;
import net.minecraft.class_9274;
import net.minecraft.class_9285;
import net.minecraft.item.*;
import net.minecraft.registry.*;
import java.util.function.Function;

public final class WandryHP implements ModInitializer {
    public static final String MOD_ID = "wandry_hp";
    public static final class_1792 AMETHYST_WAND = wand("amethyst_wand", MagicWandItem.Spell.EXPELLIARMUS, MagicWandItem.Style.AMETHYST);
    public static final class_1792 BONE_WAND = wand("bone_wand", MagicWandItem.Spell.CRUCIO, MagicWandItem.Style.BONE);
    public static final class_1792 CELESTIAL_WAND = wand("celestial_wand", MagicWandItem.Spell.IMPERIUS, MagicWandItem.Style.CELESTIAL);
    public static final class_1792 DRAGON_WAND = wand("dragon_wand", MagicWandItem.Spell.CORINFICUS, MagicWandItem.Style.DRAGON);
    public static final class_1792 EMERALD_WAND = wand("emerald_wand", MagicWandItem.Spell.PETRIFICUS_TOTALIS, MagicWandItem.Style.EMERALD);
    public static final class_1792 MAGMA_WAND = wand("magma_wand", MagicWandItem.Spell.SECTUMSEMPRA, MagicWandItem.Style.MAGMA);
    public static final class_1792 WIDOW_WAND = wand("widow_wand", MagicWandItem.Spell.AVADA_KEDAVRA, MagicWandItem.Style.WIDOW);

    /** Chapéu: slot da cabeça, +5 corações (10 de vida), 15% menos repulsão e 30% mais velocidade. */
    public static final class_1792 WITCH_HAT = register("witch_hat", class_1792::new, new class_1792.class_1793().method_7889(1)
        .method_63682(class_1304.field_6169)
        .method_57348(class_9285.method_57480()
            .method_57487(class_5134.field_23716,
                new class_1322(id("witch_hat_health"), 10.0, class_1322.class_1323.field_6328),
                class_9274.field_49223)
            .method_57487(class_5134.field_23718,
                new class_1322(id("witch_hat_knockback"), 0.15, class_1322.class_1323.field_6328),
                class_9274.field_49223)
            .method_57487(class_5134.field_23719,
                new class_1322(id("witch_hat_speed"), 0.30, class_1322.class_1323.field_6330),
                class_9274.field_49223)
            .method_57486()));
    public static final class_1792 WITCH_BROOM = register("witch_broom", BroomItem::new, new class_1792.class_1793().method_7889(1));
    public static final class_1792 SPELL_SCROLL = register("spell_scroll", ScrollItem::new, new class_1792.class_1793().method_7889(16));

    public static final class_1299<BroomEntity> BROOM = entity("witch_broom",
        class_1299.class_1300.method_5903(BroomEntity::new, class_1311.field_17715)
            .method_17687(0.9f, 0.4f).method_27299(10).method_27300(1).method_55689(0.45f));
    public static final class_1299<SpellProjectileEntity> SPELL_PROJECTILE = entity("spell_projectile",
        class_1299.class_1300.<SpellProjectileEntity>method_5903(SpellProjectileEntity::new, class_1311.field_17715)
            .method_17687(0.3f, 0.3f).method_27299(4).method_27300(5));

    public static final class_5321<class_1761> GROUP_KEY = class_5321.method_29179(class_7924.field_44688, id("main"));
    public static final class_1761 GROUP = FabricItemGroup.builder().method_47320(() -> new class_1799(AMETHYST_WAND))
        .method_47321(class_2561.method_43471("itemGroup.wandry_hp.main"))
        .method_47317((ctx, entries) -> { entries.method_45421(AMETHYST_WAND); entries.method_45421(BONE_WAND); entries.method_45421(CELESTIAL_WAND); entries.method_45421(DRAGON_WAND); entries.method_45421(EMERALD_WAND); entries.method_45421(MAGMA_WAND); entries.method_45421(WIDOW_WAND); entries.method_45421(WITCH_HAT); entries.method_45421(WITCH_BROOM); entries.method_45421(SPELL_SCROLL); }).method_47324();

    private static class_1792 wand(String name, MagicWandItem.Spell spell, MagicWandItem.Style style) {
        return register(name, s -> new MagicWandItem(spell, style, s), new class_1792.class_1793().method_7889(1));
    }

    private static <T extends class_1792> T register(String name, Function<class_1792.class_1793, T> factory, class_1792.class_1793 settings) {
        class_5321<class_1792> key = class_5321.method_29179(class_7924.field_41197, id(name));
        return class_2378.method_39197(class_7923.field_41178, key, factory.apply(settings.method_63686(key)));
    }

    private static <T extends class_1297> class_1299<T> entity(String name, class_1299.class_1300<T> builder) {
        class_5321<class_1299<?>> key = class_5321.method_29179(class_7924.field_41266, id(name));
        return class_2378.method_39197(class_7923.field_41177, key, builder.method_5905(key));
    }

    public static class_2960 id(String path) { return class_2960.method_60655(MOD_ID, path); }

    @Override public void onInitialize() {
        class_2378.method_39197(class_7923.field_44687, GROUP_KEY, GROUP);
        WandryHPEvents.initialize();
    }
}
