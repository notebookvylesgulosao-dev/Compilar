package com.wandryhp;

import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1282;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1313;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_243;
import net.minecraft.class_2487;
import net.minecraft.class_2945;
import net.minecraft.class_3218;

/**
 * Vassoura montável. Movimento controlado pelo servidor: W/A/S/D andam na direção do olhar (plano horizontal),
 * Espaço sobe e Ctrl desce, a 5 blocos por segundo. Shift desmonta e devolve a vassoura ao inventário.
 */
public final class BroomEntity extends class_1297 {
    public static final double SPEED = 5.0 / 20.0; // 5 blocos por segundo
    public static final int FORWARD = 1, BACK = 2, LEFT = 4, RIGHT = 8, UP = 16, DOWN = 32;

    private int input;

    public BroomEntity(class_1299<? extends BroomEntity> type, class_1937 world) {
        super(type, world);
        method_5875(true);
    }

    public void setInput(int flags) { this.input = flags; }

    @Override protected void method_5693(class_2945.class_9222 builder) {}
    @Override protected void method_5749(class_2487 nbt) {}
    @Override protected void method_5652(class_2487 nbt) {}

    @Override public boolean method_5863() { return !method_31481(); }
    @Override protected boolean method_5818(class_1297 passenger) { return method_5685().isEmpty(); }

    @Override public class_1269 method_5688(class_1657 player, class_1268 hand) {
        if (player.method_5715()) return class_1269.field_5811;
        if (method_37908().field_9236) return class_1269.field_5812;
        return player.method_5804(this) ? class_1269.field_21466 : class_1269.field_5811;
    }

    @Override public void method_5773() {
        super.method_5773();
        if (method_37908().field_9236) return;
        class_1297 rider = method_31483();
        class_243 velocity = class_243.field_1353;
        if (rider != null) {
            method_36456(rider.method_36454());
            double forward = ((input & FORWARD) != 0 ? 1 : 0) - ((input & BACK) != 0 ? 1 : 0);
            double left = ((input & LEFT) != 0 ? 1 : 0) - ((input & RIGHT) != 0 ? 1 : 0);
            double up = ((input & UP) != 0 ? 1 : 0) - ((input & DOWN) != 0 ? 1 : 0);
            double rad = Math.toRadians(rider.method_36454());
            double sin = Math.sin(rad), cos = Math.cos(rad);
            class_243 dir = new class_243(-sin * forward + cos * left, up, cos * forward + sin * left);
            if (dir.method_1027() > 1.0E-6) velocity = dir.method_1029().method_1021(SPEED);
        } else {
            input = 0;
        }
        method_18799(velocity);
        if (velocity.method_1027() > 0) method_5784(class_1313.field_6308, velocity);
    }

    /** Desmontar (Shift) devolve a vassoura ao inventário de quem estava nela. */
    @Override protected void method_5793(class_1297 passenger) {
        super.method_5793(passenger);
        if (!method_37908().field_9236 && !method_31481() && method_5685().isEmpty()) {
            if (passenger instanceof class_1657 player && !player.method_31549().field_7477) {
                player.method_31548().method_7398(new class_1799(WandryHP.WITCH_BROOM));
            }
            method_31472();
        }
    }

    /** Bater na vassoura vazia recupera o item. */
    @Override public boolean method_64397(class_3218 world, class_1282 source, float amount) {
        if (method_31481() || method_5782()) return false;
        if (source.method_5529() instanceof class_1657 player) {
            if (!player.method_31549().field_7477) player.method_31548().method_7398(new class_1799(WandryHP.WITCH_BROOM));
            method_31472();
            return true;
        }
        return false;
    }
}
