package com.wandryhp.client;

import com.wandryhp.BroomEntity;
import net.minecraft.class_10017;
import net.minecraft.class_3532;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_5617;
import net.minecraft.class_7833;
import net.minecraft.class_897;

public final class BroomRenderer extends class_897<BroomEntity, BroomRenderer.State> {
    public static final class State extends class_10017 {
        float yaw;
    }

    public BroomRenderer(class_5617.class_5618 context) { super(context); }

    @Override public State method_55269() { return new State(); }

    @Override public void updateRenderState(BroomEntity entity, State state, float tickDelta) {
        super.method_62354(entity, state, tickDelta);
        state.yaw = class_3532.method_16439(tickDelta, entity.field_5982, entity.method_36454());
    }

    @Override public void render(State state, class_4587 matrices, class_4597 vertexConsumers, int light) {
        matrices.method_22903();
        matrices.method_22904(0, 0.3, 0);
        // o modelo aponta para +Z (cabo à frente, cerdas atrás)
        matrices.method_22907(class_7833.field_40716.rotationDegrees(-state.yaw));
        QuadModel.get("witch_broom").render(matrices, vertexConsumers, light);
        matrices.method_22909();
        super.method_3936(state, matrices, vertexConsumers, light);
    }
}
