# Relatório de correções (revisão para 1.21.4 / Fabric / Java 21)

## Resultado do build
- `./gradlew build` NÃO gerou JAR nesta revisão.
- Gradle 8.12 (baixado do GitHub) executou e leu `settings.gradle`/`build.gradle`, mas falhou em:
  `Plugin [id: 'fabric-loom', version: '1.9.2'] was not found` — `maven.fabricmc.net` é inacessível no ambiente
  (também inacessíveis: services.gradle.org, Maven Central e servidores da Mojang).
- Portanto o código Java NÃO foi compilado: foi revisado manualmente contra a API Yarn 1.21.4.

## Corrigido
- Gradle: adicionados `gradlew`, `gradlew.bat`, `gradle/wrapper/*` (Gradle 8.12), `.gitignore`; versões centralizadas em
  `gradle.properties` (Loom 1.9.2, Yarn 1.21.4+build.8, Loader 0.16.10, Fabric API 0.119.4+1.21.4); `fabric.mod.json` com `license`.
- Receitas (15): formato 1.21.4 — ingredientes como string (`"minecraft:stick"`, não `{"item":...}`) e linhas do padrão
  com a mesma largura (antes eram inválidas, p.ex. `["A","ASA","A"]`; a receita do chapéu tinha linha vazia).
  Padrões foram centralizados com espaços; no chapéu a 2ª linha virou `L L`. Confira se é a forma desejada.
- Modelos: o vanilla 1.21.4 só aceita rotação de elemento em -45/-22.5/0/22.5/45. Seis modelos tinham outros ângulos
  (amethyst_prop, bone_prop, celestial_prop, emerald_wand, magma_prop, widow_prop). Os ângulos foram ajustados ao valor
  legal mais próximo; o maior desvio é 26,6° em emerald_wand (valores acima de 45° ficaram em 45°).
  Originais: `docs/modelos_json_antes_da_correcao/`; lista completa: `docs/ajustes_de_rotacao.json`;
  os `.bbmodel` em `blockbench/` não foram tocados.
- Adicionado `lang/en_us.json` (fallback); `pt_br.json` intacto.

## Verificado sem alteração
- JSON de definições de itens (1.21.4), referências de textura, faces, UVs e eixos: consistentes.
- Nenhuma funcionalidade removida.

## Não verificado
- Compilação Java, carregamento no jogo, aparência dos modelos ajustados.


## Ajuste da montaria da vassoura (19/11/2026)

- Substituído o voo vanilla do jogador por uma entidade `BroomEntity` montável.
- O jogador passa a ser passageiro real e recebe a pose sentada padrão do Minecraft.
- Controles enviados ao servidor: WASD para direção, Espaço para subir e Shift para descer.
- A entidade usa o modelo de item 3D da vassoura no renderer próprio.
- O ajuste de posição da varinha não foi alterado nesta revisão.
- A compilação não pôde ser verificada: o Gradle Wrapper tentou baixar Gradle 8.12, mas o ambiente não conseguiu resolver `services.gradle.org` (sem conexão DNS).
