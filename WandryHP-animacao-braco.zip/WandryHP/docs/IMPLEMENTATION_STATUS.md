# Estado da implementação

## Implementado

- Estrutura Gradle/Loom, Fabric Loader, Fabric API, Java 21 e metadados Minecraft 1.21.4.
- Registro de sete varinhas, seis props, vassoura, chapéu e pergaminho.
- Modelos 3D de itens convertidos dos `.bbmodel` recebidos e modelos originais preservados em `blockbench/`.
- Roda circular de sete opções com tecla G e sincronização de seleção via Custom Payload.
- Preparação visual da varinha por 20 ticks em primeira e terceira pessoa; manifestação local de partículas coloridas, sem projétil ou dano.
- Efeitos decorativos individualizados dos props.
- Montaria voadora própria para a vassoura, com passageiro real, assento e controles de voo enviados ao servidor.
- Receitas básicas e idioma pt_BR.

## Parcial

- A vassoura agora é uma entidade montável com assento e movimento aéreo próprio. A pose sentada usa a animação vanilla de passageiro; ainda não há animação exclusiva de cavalgada.
- A animação da varinha usa a pose vanilla de arco; não há keyframes customizados.
- A conversão de `.bbmodel` para JSON de item preserva cubos, UVs e rotação de um eixo por cubo; rotações compostas podem não ser idênticas ao Blockbench.
- Compilação: o Gradle 8.12 foi executado, mas parou na resolução do plugin Fabric Loom (sem acesso a maven.fabricmc.net). Nenhum JAR foi gerado nessa revisão; compile com `./gradlew build` em uma máquina com internet.

## Escopo desta entrega

Esta versão contém itens decorativos, mobilidade e efeitos visuais não-combativos. Não implementa projéteis, dano, efeitos de combate, controle de entidades ou alteração de saúde.
