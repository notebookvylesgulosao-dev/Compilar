package com.wandryhp.client;

import com.wandryhp.BroomEntity;
import com.wandryhp.WandryHP;
import net.minecraft.client.item.ItemModelManager;
import net.minecraft.client.render.OverlayTexture;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.entity.EntityRenderer;
import net.minecraft.client.render.entity.EntityRendererFactory;
import net.minecraft.client.render.entity.state.EntityRenderState;
import net.minecraft.client.render.item.ItemRenderState;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.item.ItemStack;
import net.minecraft.item.ModelTransformationMode;
import net.minecraft.util.math.RotationAxis;

public final class BroomEntityRenderer extends EntityRenderer<BroomEntity, BroomEntityRenderer.State> {
    public static final class State extends EntityRenderState {
        final ItemRenderState item = new ItemRenderState();
    }

    private final ItemModelManager itemModelManager;

    public BroomEntityRenderer(EntityRendererFactory.Context context) {
        super(context);
        this.itemModelManager = context.getItemModelManager();
    }

    @Override
    public State createRenderState() { return new State(); }

    @Override
    public void updateRenderState(BroomEntity entity, State state, float tickDelta) {
        super.updateRenderState(entity, state, tickDelta);
        itemModelManager.updateForNonLivingEntity(state.item, new ItemStack(WandryHP.WITCH_BROOM),
                ModelTransformationMode.FIXED, entity);
    }

    @Override
    public void render(State state, MatrixStack matrices, VertexConsumerProvider vertices, int light) {
        matrices.push();
        // O modelo 3D da própria vassoura é reutilizado como corpo visível da montaria.
        matrices.translate(0.0, 0.12, 0.0);
        matrices.multiply(RotationAxis.POSITIVE_X.rotationDegrees(90.0f));
        state.item.render(matrices, vertices, light, OverlayTexture.DEFAULT_UV);
        matrices.pop();
        super.render(state, matrices, vertices, light);
    }
}
