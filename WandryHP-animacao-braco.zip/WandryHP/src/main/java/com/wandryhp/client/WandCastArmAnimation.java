package com.wandryhp.client;

import com.wandryhp.MagicWandItem;
import java.util.HashMap;
import java.util.Map;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.model.ModelPart;
import net.minecraft.client.render.entity.state.PlayerEntityRenderState;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.Arm;
import net.minecraft.util.Hand;
import net.minecraft.util.math.MathHelper;

/**
 * Animação do braço que segura a varinha (aplicada via Mixin em {@code BipedEntityModel#setAngles}).
 *
 * <pre>
 *  CARGA   : o braço sobe gradualmente e, na parte final, recua (arma o lançamento).
 *  ARREMESSO: ao disparar, o braço é esticado rapidamente para frente, na direção da mira.
 *  SEGURA  : breve pausa na pose esticada.
 *  RETORNO : o braço volta suavemente à pose de descanso do Minecraft.
 * </pre>
 *
 * Toda a curva é contínua: cada fase parte exatamente da pose em que a anterior terminou, e a
 * pose final coincide com a pose original do jogo, então não há saltos entre as fases.
 * Usa apenas o tempo de renderização (ticks + parcial), portanto roda na taxa de quadros.
 */
public final class WandCastArmAnimation {
    // ---- Duração das fases (em ticks; 20 ticks = 1 s) ----
    private static final float CHARGE_RAISE_TICKS = 14.0F;   // subida gradual do braço
    private static final float CHARGE_COCK_START = 9.0F;     // início do recuo (sobrepõe o fim da subida)
    private static final float CHARGE_COCK_TICKS = 11.0F;    // duração do recuo
    private static final float THRUST_TICKS = 2.5F;          // estocada rápida
    private static final float HOLD_TICKS = 3.0F;            // pausa com o braço esticado
    private static final float RETURN_TICKS = 14.0F;         // retorno natural
    private static final float CANCEL_RETURN_TICKS = 9.0F;   // retorno quando a carga é solta cedo demais
    private static final float MIN_FIRE_CHARGE = 7.5F;       // o servidor só dispara a partir de 8 ticks de carga

    // ---- Poses-chave do braço (radianos) ----
    private static final float RAISED_PITCH = -2.00F;        // braço erguido à frente e para cima
    private static final float RAISED_INWARD = 0.12F;
    private static final float RAISED_OUTWARD = 0.10F;
    private static final float COCKED_PITCH = -2.95F;        // braço recuado, quase vertical, antes do lançamento
    private static final float COCKED_INWARD = 0.04F;
    private static final float COCKED_OUTWARD = 0.30F;
    private static final float FORWARD_INWARD = 0.10F;       // estocada: mesma convenção do arco vanilla

    private enum Phase { CHARGE, THRUST, HOLD, RETURN, CANCEL }

    private static final class Cast {
        Phase phase = Phase.CHARGE;
        boolean rightArm;
        float phaseStart;
        float lastCharge;
        boolean carried;                        // a carga começou no meio de um retorno anterior
        final float[] carry = new float[3];     // pose no instante em que a carga começou
        final float[] release = new float[3];   // pose no instante em que a carga foi solta
    }

    private static final Map<Integer, Cast> CASTS = new HashMap<>();

    private WandCastArmAnimation() {}

    /** Chamado no fim de {@code setAngles}: sobrescreve o braço da varinha enquanto a animação estiver ativa. */
    public static void apply(PlayerEntityRenderState state, ModelPart head, ModelPart rightArm, ModelPart leftArm) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.world == null) return;
        Entity entity = client.world.getEntityById(state.id);
        if (!(entity instanceof PlayerEntity player)) return;

        // Poses especiais do corpo (planar, nadar, deitar) ficam com o comportamento original.
        if (state.isGliding || state.isSwimming || state.leaningPitch > 0.0F) {
            CASTS.remove(state.id);
            return;
        }

        final float now = state.age;
        Cast cast = CASTS.get(state.id);
        if (cast != null && now < cast.phaseStart - 5.0F) { // relógio voltou (nova entidade/mundo)
            CASTS.remove(state.id);
            cast = null;
        }

        final boolean charging = player.isUsingItem() && player.getActiveItem().getItem() instanceof MagicWandItem;
        final float[] pose = new float[3];

        if (charging) {
            boolean right = (player.getActiveHand() == Hand.MAIN_HAND) == (player.getMainArm() == Arm.RIGHT);
            float frac = MathHelper.clamp(now - player.age, 0.0F, 1.0F);
            float charge = state.itemUseTime + frac;

            if (cast == null || cast.phase != Phase.CHARGE || cast.rightArm != right) {
                Cast next = new Cast();
                next.rightArm = right;
                next.phaseStart = now;
                float[] from = new float[3];
                if (cast != null && cast.rightArm == right && evaluate(cast, now, state, head, rightArm, leftArm, false, from)) {
                    next.carried = true;
                } else {
                    restPose(state, right, from);
                }
                System.arraycopy(from, 0, next.carry, 0, 3);
                cast = next;
                CASTS.put(state.id, cast);
            }
            cast.lastCharge = charge;
            chargePose(cast, charge, state, head, pose);
        } else if (cast != null) {
            if (cast.phase == Phase.CHARGE) { // acabou de soltar: decide entre disparo e cancelamento
                chargePose(cast, cast.lastCharge, state, head, cast.release);
                cast.phase = cast.lastCharge >= MIN_FIRE_CHARGE ? Phase.THRUST : Phase.CANCEL;
                cast.phaseStart = now;
            }
            if (!evaluate(cast, now, state, head, rightArm, leftArm, true, pose)) {
                CASTS.remove(state.id);
                return;
            }
        } else {
            return;
        }

        ModelPart arm = cast.rightArm ? rightArm : leftArm;
        arm.pitch = pose[0];
        arm.yaw = pose[1];
        arm.roll = pose[2];

        if (CASTS.size() > 16) CASTS.keySet().removeIf(id -> client.world.getEntityById(id) == null);
    }

    // ---------------------------------------------------------------------------------------------
    // Fases
    // ---------------------------------------------------------------------------------------------

    /** Pose durante a carga: sobe gradualmente e, no fim, recua. {@code out = {pitch, yaw, roll}}. */
    private static void chargePose(Cast cast, float charge, PlayerEntityRenderState state, ModelPart head, float[] out) {
        final float side = cast.rightArm ? 1.0F : -1.0F;
        final float u = Math.max(0.0F, charge);
        final float[] base = new float[3];
        restPose(state, cast.rightArm, base);

        final float raise = smootherStep(u / CHARGE_RAISE_TICKS);
        final float cock = smoothStep((u - CHARGE_COCK_START) / CHARGE_COCK_TICKS);

        float pitch = base[0] + (RAISED_PITCH - base[0]) * raise + (COCKED_PITCH - RAISED_PITCH) * cock;
        pitch += head.pitch * 0.5F * raise;
        float inward = RAISED_INWARD * raise + (COCKED_INWARD - RAISED_INWARD) * cock;
        float yaw = base[1] - side * inward + head.yaw * 0.6F * raise;
        float outward = RAISED_OUTWARD * raise + (COCKED_OUTWARD - RAISED_OUTWARD) * cock;
        float roll = base[2] + side * outward;

        if (cast.carried) {
            // Continuidade quando a carga começa durante o retorno da anterior.
            float carryBlend = smoothStep(u / 4.0F);
            float restBlend = smoothStep(u / 6.0F);
            float[] start = {
                    MathHelper.lerp(restBlend, cast.carry[0], base[0]),
                    MathHelper.lerp(restBlend, cast.carry[1], base[1]),
                    MathHelper.lerp(restBlend, cast.carry[2], base[2])};
            pitch = MathHelper.lerp(carryBlend, start[0], pitch);
            yaw = MathHelper.lerp(carryBlend, start[1], yaw);
            roll = MathHelper.lerp(carryBlend, start[2], roll);
        }
        out[0] = pitch;
        out[1] = yaw;
        out[2] = roll;
    }

    /** Pose com o braço esticado na direção da mira (convenção do arco do Minecraft). */
    private static void forwardPose(Cast cast, ModelPart head, float[] out) {
        final float side = cast.rightArm ? 1.0F : -1.0F;
        out[0] = -MathHelper.HALF_PI + head.pitch;
        out[1] = -side * FORWARD_INWARD + head.yaw;
        out[2] = 0.0F;
    }

    /** Avalia as fases pós-carga. Retorna {@code false} quando a animação terminou. */
    private static boolean evaluate(Cast cast, float now, PlayerEntityRenderState state, ModelPart head,
                                    ModelPart rightArm, ModelPart leftArm, boolean vanillaIsRest, float[] out) {
        // Avança as fases pelo tempo decorrido (robusto a quadros longos).
        while (true) {
            float t = now - cast.phaseStart;
            if (cast.phase == Phase.THRUST && t >= THRUST_TICKS) {
                cast.phase = Phase.HOLD; cast.phaseStart += THRUST_TICKS;
            } else if (cast.phase == Phase.HOLD && t >= HOLD_TICKS) {
                cast.phase = Phase.RETURN; cast.phaseStart += HOLD_TICKS;
            } else {
                break;
            }
        }
        final float t = Math.max(0.0F, now - cast.phaseStart);

        // Depois de soltar a varinha, o jogo já posicionou o braço na pose de descanso real: é o destino exato.
        // Se uma nova carga já começou (pose de arco do jogo no braço), usa o cálculo equivalente.
        final float[] rest = new float[3];
        if (vanillaIsRest) {
            ModelPart arm = cast.rightArm ? rightArm : leftArm;
            rest[0] = arm.pitch; rest[1] = arm.yaw; rest[2] = arm.roll;
        } else {
            restPose(state, cast.rightArm, rest);
        }

        switch (cast.phase) {
            case CHARGE -> {
                chargePose(cast, cast.lastCharge, state, head, out);
                return true;
            }
            case THRUST -> {
                float[] forward = new float[3];
                forwardPose(cast, head, forward);
                float e = easeOutBack(MathHelper.clamp(t / THRUST_TICKS, 0.0F, 1.0F), 0.8F);
                for (int i = 0; i < 3; i++) out[i] = cast.release[i] + (forward[i] - cast.release[i]) * e;
                return true;
            }
            case HOLD -> {
                forwardPose(cast, head, out);
                return true;
            }
            case RETURN -> {
                if (t >= RETURN_TICKS) return false;
                float[] forward = new float[3];
                forwardPose(cast, head, forward);
                float e = smootherStep(t / RETURN_TICKS);
                for (int i = 0; i < 3; i++) out[i] = forward[i] + (rest[i] - forward[i]) * e;
                return true;
            }
            case CANCEL -> {
                if (t >= CANCEL_RETURN_TICKS) return false;
                float e = smootherStep(t / CANCEL_RETURN_TICKS);
                for (int i = 0; i < 3; i++) out[i] = cast.release[i] + (rest[i] - cast.release[i]) * e;
                return true;
            }
        }
        return false;
    }

    // ---------------------------------------------------------------------------------------------
    // Utilidades
    // ---------------------------------------------------------------------------------------------

    /**
     * Pose de descanso do braço que segura um item (balanço da caminhada, respiração, agachar),
     * reproduzindo o cálculo do Minecraft para servir de ponto de partida/chegada contínuo.
     */
    private static void restPose(PlayerEntityRenderState state, boolean right, float[] out) {
        final float side = right ? 1.0F : -1.0F;
        final float inverse = state.limbAmplitudeInverse == 0.0F ? 1.0F : state.limbAmplitudeInverse;
        float swing = MathHelper.cos(state.limbFrequency * 0.6662F + (right ? MathHelper.PI : 0.0F))
                * 2.0F * state.limbAmplitudeMultiplier * 0.5F / inverse;
        if (state.hasVehicle) swing += -MathHelper.PI / 5.0F;
        float pitch = swing * 0.5F - MathHelper.PI / 10.0F;          // pose "item na mão"
        if (state.isInSneakingPose) pitch += 0.4F;
        pitch += side * MathHelper.sin(state.age * 0.067F) * 0.05F;  // respiração
        out[0] = pitch;
        out[1] = 0.0F;
        out[2] = side * (MathHelper.cos(state.age * 0.09F) * 0.05F + 0.05F);
    }

    private static float smoothStep(float x) {
        x = MathHelper.clamp(x, 0.0F, 1.0F);
        return x * x * (3.0F - 2.0F * x);
    }

    private static float smootherStep(float x) {
        x = MathHelper.clamp(x, 0.0F, 1.0F);
        return x * x * x * (x * (x * 6.0F - 15.0F) + 10.0F);
    }

    private static float easeOutBack(float x, float overshoot) {
        float c3 = overshoot + 1.0F;
        float p = x - 1.0F;
        return 1.0F + c3 * p * p * p + overshoot * p * p;
    }
}
