package com.wandryhp.client;

import com.wandryhp.SpellProjectileEntity;
import net.minecraft.client.item.ItemModelManager;
import net.minecraft.client.render.OverlayTexture;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.entity.EntityRenderer;
import net.minecraft.client.render.entity.EntityRendererFactory;
import net.minecraft.client.render.entity.state.EntityRenderState;
import net.minecraft.client.render.item.ItemRenderState;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.item.ModelTransformationMode;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.RotationAxis;

/** Renderiza o núcleo em 3D e vários itens Minecraft como rastro, sem criar drops. */
public final class SpellProjectileRenderer extends EntityRenderer<SpellProjectileEntity, SpellProjectileRenderer.State> {
    private static final int TRAIL_SEGMENTS = 12;
    private static final Item[] CORES = {Items.EMERALD, Items.FIRE_CHARGE, Items.REDSTONE, Items.AMETHYST_SHARD, Items.GOLD_NUGGET, Items.IRON_NUGGET, Items.PURPLE_DYE};
    private static final Item[][] TRAILS = {
        {Items.EMERALD, Items.LIME_DYE, Items.MOSS_BLOCK, Items.SLIME_BALL},
        {Items.BLAZE_POWDER, Items.FIRE_CHARGE, Items.MAGMA_CREAM, Items.ORANGE_DYE},
        {Items.REDSTONE, Items.RED_DYE, Items.NETHER_WART, Items.FIRE_CORAL},
        {Items.QUARTZ, Items.WHITE_DYE, Items.AMETHYST_SHARD, Items.GLOWSTONE_DUST},
        {Items.GOLD_NUGGET, Items.HONEYCOMB, Items.YELLOW_DYE, Items.GLOWSTONE_DUST},
        {Items.IRON_NUGGET, Items.GRAY_DYE, Items.STONE, Items.INK_SAC},
        {Items.AMETHYST_SHARD, Items.PURPLE_DYE, Items.CHORUS_FRUIT, Items.PURPLE_GLAZED_TERRACOTTA}
    };

    public static final class State extends EntityRenderState {
        final ItemRenderState core = new ItemRenderState();
        final ItemRenderState[] trail = new ItemRenderState[TRAIL_SEGMENTS];
        float yaw;
        float pitch;
        float visualAge;
        State() { for (int i = 0; i < trail.length; i++) trail[i] = new ItemRenderState(); }
    }

    private final ItemModelManager itemModelManager;

    public SpellProjectileRenderer(EntityRendererFactory.Context context) {
        super(context);
        this.itemModelManager = context.getItemModelManager();
    }

    @Override
    public State createRenderState() { return new State(); }

    @Override
    public void updateRenderState(SpellProjectileEntity entity, State state, float tickDelta) {
        super.updateRenderState(entity, state, tickDelta);
        state.yaw = entity.getYaw();
        state.pitch = entity.getPitch();
        state.visualAge = entity.getVisualAge() + tickDelta;
        int spell = Math.floorMod(entity.getSpellIndex(), CORES.length);
        itemModelManager.updateForNonLivingEntity(state.core, new ItemStack(CORES[spell]), ModelTransformationMode.FIXED, entity);
        Item[] trail = TRAILS[Math.floorMod(entity.getStyleIndex(), TRAILS.length)];
        for (int i = 1; i <= TRAIL_SEGMENTS; i++) {
            Item item = trail[(i + (int) (state.visualAge / 3)) % trail.length];
            itemModelManager.updateForNonLivingEntity(state.trail[i - 1], new ItemStack(item), ModelTransformationMode.FIXED, entity);
        }
    }

    @Override
    public void render(State state, MatrixStack matrices, VertexConsumerProvider vertices, int light) {
        float age = state.visualAge;
        matrices.push();
        matrices.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(-state.yaw));
        matrices.multiply(RotationAxis.POSITIVE_X.rotationDegrees(state.pitch));
        matrices.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(age * 13.0f));
        float pulse = 0.82f + 0.12f * MathHelper.sin(age * 0.45f);
        matrices.scale(pulse, pulse, pulse);
        state.core.render(matrices, vertices, light, OverlayTexture.DEFAULT_UV);
        matrices.pop();
        // Pequenos itens por segmento dão a sensação de uma trilha contínua.
        for (int i = 1; i <= TRAIL_SEGMENTS; i++) {
            float behind = i * 0.115f;
            float fade = 1.0f - i / 14.0f;
            matrices.push();
            matrices.translate(0, 0, behind);
            matrices.multiply(RotationAxis.POSITIVE_Y.rotationDegrees((age * 17 + i * 47) % 360));
            matrices.multiply(RotationAxis.POSITIVE_X.rotationDegrees((i * 31) % 360));
            float size = (0.12f + (i % 3) * 0.025f) * fade;
            matrices.scale(size, size, size);
            state.trail[i - 1].render(matrices, vertices, light, OverlayTexture.DEFAULT_UV);
            matrices.pop();
        }
        super.render(state, matrices, vertices, light);
    }
}
