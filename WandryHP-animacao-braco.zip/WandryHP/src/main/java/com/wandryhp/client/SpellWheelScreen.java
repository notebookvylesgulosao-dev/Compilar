package com.wandryhp.client;

import com.wandryhp.MagicWandItem;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

/** Roda circular de sete feitiços, abre com G. A seleção é sincronizada ao servidor ao confirmar. */
public final class SpellWheelScreen extends Screen {
    private static final int[] COLORS={0xFF22C55E,0xFFEF3038,0xFFF0142B,0xFFF4F4F4,0xFFFFD447,0xFF999999,0xFF963DCE};
    private static final int N=MagicWandItem.Spell.values().length;
    private static final double STEP=Math.PI*2/N;
    private static final int INNER=35,OUTER=91;
    private static int selected=0;
    public SpellWheelScreen(){super(Text.translatable("screen.wandry_hp.wheel"));}
    private static double angle(double x,double y){double a=Math.atan2(x,-y);return a<0?a+Math.PI*2:a;}
    private int sector(double x,double y){double r=Math.hypot(x,y);if(r<INNER||r>OUTER)return -1;return (int)(angle(x,y)/STEP)%N;}
    @Override public void mouseMoved(double x,double y){int s=sector(x-width/2.0,y-height/2.0);if(s>=0)selected=s;super.mouseMoved(x,y);}
    @Override public void render(DrawContext c,int mx,int my,float delta){
        int cx=width/2,cy=height/2,hover=sector(mx-cx,my-cy);
        for(int y=-OUTER;y<=OUTER;y+=2)for(int x=-OUTER;x<=OUTER;x+=2){
            double r=Math.hypot(x+1,y+1);if(r<INNER||r>OUTER)continue;double a=angle(x+1,y+1),f=a%STEP;int i=(int)(a/STEP)%N;
            if(Math.min(f,STEP-f)*r<1.6)continue;
            int alpha=i==selected?0xEA:i==hover?0xC8:0x88;
            c.fill(cx+x,cy+y,cx+x+2,cy+y+2,(alpha<<24)|(COLORS[i]&0xFFFFFF));
        }
        double mid=(INNER+OUTER)/2.0;
        for(int i=0;i<N;i++){
            double a=(i+.5)*STEP;int x=cx+(int)(Math.sin(a)*mid),y=cy-(int)(Math.cos(a)*mid);
            c.drawCenteredTextWithShadow(textRenderer,Integer.toString(i+1),x,y-4,0xFFFFFF);
            int lx=cx+(int)(Math.sin(a)*(OUTER+16)),ly=cy-(int)(Math.cos(a)*(OUTER+16));
            c.drawCenteredTextWithShadow(textRenderer,MagicWandItem.Spell.values()[i].label,lx,ly-4,i==selected?0xFFFFFF:0xC7C7C7);
        }
        c.drawCenteredTextWithShadow(textRenderer,"WandryHP",cx,cy-OUTER-25,0xD9B8FF);
        c.drawCenteredTextWithShadow(textRenderer,MagicWandItem.Spell.values()[selected].label,cx,cy-4,0xFFFFFF);
        c.drawCenteredTextWithShadow(textRenderer,"Clique ou pressione 1–7 para confirmar · G/Esc para fechar",cx,cy+OUTER+25,0xDDDDDD);
    }
    private void confirm(){WandryHPClient.commit(selected);close();}
    @Override public boolean mouseClicked(double x,double y,int button){if(button==0){int i=sector(x-width/2.0,y-height/2.0);if(i>=0){selected=i;confirm();return true;}}return super.mouseClicked(x,y,button);}
    @Override public boolean keyPressed(int key,int scan,int mods){
        if(key>=GLFW.GLFW_KEY_1&&key<=GLFW.GLFW_KEY_7){selected=key-GLFW.GLFW_KEY_1;confirm();return true;}
        if(key==GLFW.GLFW_KEY_LEFT||key==GLFW.GLFW_KEY_A){selected=(selected+N-1)%N;return true;}
        if(key==GLFW.GLFW_KEY_RIGHT||key==GLFW.GLFW_KEY_D){selected=(selected+1)%N;return true;}
        if(key==GLFW.GLFW_KEY_ENTER||key==GLFW.GLFW_KEY_SPACE){confirm();return true;}
        if(key==GLFW.GLFW_KEY_ESCAPE||key==GLFW.GLFW_KEY_G){close();return true;}
        return super.keyPressed(key,scan,mods);
    }
    @Override public boolean shouldPause(){return false;}
}
