package com.wandryhp.client;

import com.wandryhp.SpellSelectionPayload;
import com.wandryhp.BroomEntity;
import com.wandryhp.BroomControlPayload;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

public final class WandryHPClient implements ClientModInitializer {
    private static KeyBinding wheelKey;
    @Override public void onInitializeClient(){
        net.fabricmc.fabric.api.client.rendering.v1.EntityRendererRegistry.register(com.wandryhp.WandryHP.BROOM_ENTITY, BroomEntityRenderer::new);
        net.fabricmc.fabric.api.client.rendering.v1.EntityRendererRegistry.register(com.wandryhp.WandryHP.SPELL_PROJECTILE, SpellProjectileRenderer::new);
        wheelKey=KeyBindingHelper.registerKeyBinding(new KeyBinding("key.wandry_hp.spell_wheel",InputUtil.Type.KEYSYM,GLFW.GLFW_KEY_G,"category.wandry_hp"));
        ClientTickEvents.END_CLIENT_TICK.register(client->{
            while(wheelKey.wasPressed()) if(client.player!=null && client.currentScreen==null) client.setScreen(new SpellWheelScreen());
            if (client.player != null && client.player.getVehicle() instanceof BroomEntity) {
                float forward = (client.options.forwardKey.isPressed() ? 1.0f : 0.0f) - (client.options.backKey.isPressed() ? 1.0f : 0.0f);
                float strafe = (client.options.leftKey.isPressed() ? 1.0f : 0.0f) - (client.options.rightKey.isPressed() ? 1.0f : 0.0f);
                float vertical = (client.options.jumpKey.isPressed() ? 1.0f : 0.0f) - (client.options.sneakKey.isPressed() ? 1.0f : 0.0f);
                net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking.send(new BroomControlPayload(forward, strafe, vertical));
            }
        });
    }
    static void commit(int index){net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking.send(new SpellSelectionPayload(index));}
}
