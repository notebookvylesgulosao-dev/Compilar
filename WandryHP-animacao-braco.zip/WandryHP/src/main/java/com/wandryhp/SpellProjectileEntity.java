package com.wandryhp;

import net.minecraft.entity.Entity;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.data.DataTracker;
import net.minecraft.entity.data.TrackedData;
import net.minecraft.entity.data.TrackedDataHandlerRegistry;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;

/** Projétil puramente visual: não colide, não causa dano e não altera blocos. */
public final class SpellProjectileEntity extends Entity {
    private static final TrackedData<Integer> SPELL = DataTracker.registerData(SpellProjectileEntity.class, TrackedDataHandlerRegistry.INTEGER);
    private static final TrackedData<Integer> STYLE = DataTracker.registerData(SpellProjectileEntity.class, TrackedDataHandlerRegistry.INTEGER);
    private int visualAge;

    public SpellProjectileEntity(EntityType<? extends SpellProjectileEntity> type, World world) { super(type, world); setNoGravity(true); }
    public void configure(int spell, int style, Vec3d velocity) {
        dataTracker.set(SPELL, spell); dataTracker.set(STYLE, style); setVelocity(velocity); setNoGravity(true);
    }
    public int getSpellIndex() { return dataTracker.get(SPELL); }
    public int getStyleIndex() { return dataTracker.get(STYLE); }
    public int getVisualAge() { return visualAge; }
    @Override
    public boolean damage(ServerWorld world, DamageSource source, float amount) { return false; }

    @Override protected void initDataTracker(DataTracker.Builder builder) { builder.add(SPELL, 0); builder.add(STYLE, 0); }
    @Override protected void readCustomDataFromNbt(NbtCompound nbt) { visualAge = nbt.getInt("VisualAge"); }
    @Override protected void writeCustomDataToNbt(NbtCompound nbt) { nbt.putInt("VisualAge", visualAge); }
    @Override public void tick() {
        super.tick(); visualAge++;
        if (visualAge > 36) { discard(); return; }
        setPosition(getX() + getVelocity().x, getY() + getVelocity().y, getZ() + getVelocity().z);
    }
    @Override public boolean isCollidable() { return false; }
    @Override public boolean canHit() { return false; }
}
