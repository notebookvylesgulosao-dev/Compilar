# Implementação visual do projétil

- A varinha usa a pose de uso `BOW` durante a preparação de 20 ticks (aprox. 1 segundo), com a animação de braço nativa do Minecraft.
- Ao concluir a preparação, o servidor cria `SpellProjectileEntity`, sincronizada para os clientes.
- O projétil segue a direção da mira, dura até 36 ticks e não colide, não causa dano, não quebra blocos e não cria drops.
- `SpellProjectileRenderer` renderiza um núcleo 3D usando modelos de itens Minecraft e uma sequência de pequenos itens 3D atrás dele.
- Os itens do rastro são escolhidos pelo estilo da varinha e existem apenas durante a renderização; não são entidades coletáveis nem itens do mundo.

## Limitações desta entrega

A origem do projétil usa uma posição aproximada junto à mão (não a ponta geométrica exata de cada modelo de varinha). A pose é a animação nativa de arco do Minecraft, não uma animação customizada por ossos. Os arquivos `.bbmodel` fornecidos ainda não foram convertidos e ligados ao renderer; o núcleo usa modelos 3D de itens vanilla. A compilação não pôde ser validada neste ambiente porque o Gradle Wrapper precisa baixar Gradle 8.12 e o ambiente está sem acesso à rede.
